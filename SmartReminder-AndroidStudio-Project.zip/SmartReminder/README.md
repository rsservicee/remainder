# স্মার্ট রিমাইন্ডার (Smart Reminder) - Android Studio Project Guide

এই প্রজেক্টটি একটি সম্পূর্ণ Native Android Application যা Kotlin ও Jetpack Compose ব্যবহার করে নির্মিত।

## প্রজেক্টের বৈশিষ্ট্য:
1. **Kotlin ও Jetpack Compose UI**: আধুনিক ডিক্লারেটিভ ইউজার ইন্টারফেস।
2. **Room Database**: ওষুধ, কাজ এবং দৈনিক ইতিহাসের অফলাইন ডেটাবেস।
3. **Reliable AlarmManager**: `setExactAndAllowWhileIdle` ও `WakeLock` সহ ব্যাকগ্রাউন্ডে ও Doze মোডেও নির্ভুল অ্যালার্ম।
4. **Boot Receiver**: ফোন রিস্টার্টের পর স্বয়ংক্রিয়ভাবে সব অ্যালার্ম পুনঃনির্ধারণ (Reschedule)।
5. **Interactive Notification**: নোটিফিকেশন থেকেই "ওষুধ খেয়েছি" এবং "পরে মনে করিয়ে দাও" বাটন।
6. **Android 13+ সাপোর্ট**: `POST_NOTIFICATIONS` ও `SCHEDULE_EXACT_ALARM` হ্যান্ডলিং।

---

## 🛠️ Android Studio-তে কীভাবে খুলবেন ও APK তৈরি করবেন:

### ধাপ ১: প্রজেক্ট ওপেন করুন
1. জিপ (ZIP) ফাইলটি আনজিপ করুন।
2. **Android Studio** (Koala / Ladybug / Meerkat বা যেকোনো আধুনিক ভার্সন) চালু করুন।
3. **Open**-এ ক্লিক করে আনজিপ করা ফোল্ডারটি নির্বাচন করুন।
4. Gradle Sync সম্পন্ন হওয়া পর্যন্ত অপেক্ষা করুন (সব ডিপেনডেন্সি স্বয়ংক্রিয়ভাবে ডাউনলোড হবে)।

### ধাপ ২: Debug APK তৈরি করার নিয়ম
- Android Studio মেনু থেকে:
  `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)` এ ক্লিক করুন।
- অথবা টার্মিনালে রান করুন:
  ```bash
  ./gradlew assembleDebug
  ```
- সফলভাবে বিল্ড হলে `app/build/outputs/apk/debug/app-debug.apk` ফোল্ডারে APK ফাইল তৈরি হবে।
- Android Studio স্ক্রিনে নিচে ডানপাশে **"locate"** বাটনে ক্লিক করলেই সরাসরি APK ফাইলটি দেখতে পাবেন।

### ধাপ ৩: মোবাইলে সরাসরি রান করুন
- আপনার অ্যান্ড্রয়েড ফোনে **Developer Options** ও **USB Debugging** চালু করে ক্যাবল দিয়ে পিসিতে যুক্ত করুন।
- Android Studio-র উপরের সবুজ **Run 'app' (Shift + F10)** বাটনে ক্লিক করুন।
