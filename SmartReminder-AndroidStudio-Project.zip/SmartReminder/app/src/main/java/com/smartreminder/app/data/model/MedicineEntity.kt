package com.smartreminder.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dose: String,
    val type: String, // ট্যাবলেট, ক্যাপসুল, সিরাপ, ইনজেকশন ইত্যাদি
    val foodInstruction: String, // খাওয়ার আগে, খাওয়ার পরে, খালি পেটে
    val notes: String = "",
    val timesPerDay: Int,
    val scheduledTimesJson: String, // Comma-separated or JSON string of "HH:mm"
    val startDate: Long = System.currentTimeMillis(),
    val endDate: Long? = null,
    val isActive: Boolean = true,
    val colorHex: String = "#10B981"
)
