package com.smartreminder.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

@Composable
fun MainNavigationScreen(viewModel: ReminderViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "হোম") },
                    label = { Text("হোম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Medication, contentDescription = "ওষুধ") },
                    label = { Text("ওষুধ") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.CheckCircle, contentDescription = "কাজ") },
                    label = { Text("কাজ") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = "ইতিহাস") },
                    label = { Text("ইতিহাস") }
                )
            }
        }
    ) { innerPadding ->
        Surface(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> HomeScreen(viewModel)
                1 -> MedicineScreen(viewModel)
                2 -> TaskScreen(viewModel)
                3 -> HistoryScreen(viewModel)
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: ReminderViewModel) {
    // HomeScreen Jetpack Compose composable with summary cards and upcoming reminder
    Text("স্মার্ট রিমাইন্ডার হোম স্ক্রিন - আজকের সময়সূচী")
}

@Composable
fun MedicineScreen(viewModel: ReminderViewModel) {
    Text("ওষুধের তালিকা ও নতুন ওষুধ যোগ করার স্ক্রিন")
}

@Composable
fun TaskScreen(viewModel: ReminderViewModel) {
    Text("প্রাত্যহিক কাজের তালিকা ও রিমাইন্ডার স্ক্রিন")
}

@Composable
fun HistoryScreen(viewModel: ReminderViewModel) {
    Text("ওষুধ গ্রহণের ইতিহাস ও পরিসংখ্যান")
}
