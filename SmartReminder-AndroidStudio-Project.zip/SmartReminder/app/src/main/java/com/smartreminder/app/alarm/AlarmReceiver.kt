package com.smartreminder.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.smartreminder.app.notification.NotificationHelper

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_MEDICINE_ALARM = "com.smartreminder.app.ACTION_MEDICINE_ALARM"
        const val ACTION_TASK_ALARM = "com.smartreminder.app.ACTION_TASK_ALARM"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("EXTRA_TITLE") ?: "স্মার্ট রিমাইন্ডার"
        val message = intent.getStringExtra("EXTRA_MESSAGE") ?: "আপনার নির্ধারিত সময় হয়েছে।"
        val requestCode = intent.getIntExtra("EXTRA_REQUEST_CODE", 0)

        when (intent.action) {
            ACTION_MEDICINE_ALARM -> {
                val medicineId = intent.getLongExtra("EXTRA_MEDICINE_ID", -1L)
                val scheduledTime = intent.getStringExtra("EXTRA_SCHEDULED_TIME") ?: ""
                NotificationHelper.showMedicineNotification(
                    context,
                    notificationId = requestCode,
                    medicineId = medicineId,
                    title = title,
                    message = message,
                    scheduledTime = scheduledTime
                )
            }
            ACTION_TASK_ALARM -> {
                val taskId = intent.getLongExtra("EXTRA_TASK_ID", -1L)
                NotificationHelper.showTaskNotification(
                    context,
                    notificationId = requestCode,
                    taskId = taskId,
                    title = title,
                    message = message
                )
            }
        }
    }
}
