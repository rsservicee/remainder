package com.smartreminder.app.data.local

import androidx.room.*
import com.smartreminder.app.data.model.HistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM intake_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM intake_history WHERE dateString = :date ORDER BY timestamp DESC")
    fun getHistoryForDate(date: String): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity): Long

    @Query("DELETE FROM intake_history WHERE id = :id")
    suspend fun deleteHistory(id: Long)
}
