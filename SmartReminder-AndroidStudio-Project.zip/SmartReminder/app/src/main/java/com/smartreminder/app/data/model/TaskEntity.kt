package com.smartreminder.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String, // নামাজ, পানি পান, পড়াশোনা, ব্যবসা, মিটিং, বিল পরিশোধ
    val dueDate: Long, // Epoch timestamp in ms for the date
    val dueTime: String, // "HH:mm"
    val repeatType: String, // একবার, প্রতিদিন, প্রতি সপ্তাহে, কাস্টম
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val priority: String = "medium"
)
