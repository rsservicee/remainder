package com.smartreminder.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.smartreminder.app.SmartReminderApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val app = context.applicationContext as SmartReminderApp
            val scheduler = AndroidAlarmScheduler(context)

            CoroutineScope(Dispatchers.IO).launch {
                val activeMedicines = app.database.medicineDao().getActiveMedicines().firstOrNull()
                activeMedicines?.forEach { medicine ->
                    val times = medicine.scheduledTimesJson.split(",")
                    times.forEach { time ->
                        scheduler.scheduleMedicineAlarm(
                            medicineId = medicine.id,
                            timeString = time.trim(),
                            label = "সময়সূচী",
                            medicineName = medicine.name,
                            dose = medicine.dose
                        )
                    }
                }

                val pendingTasks = app.database.taskDao().getPendingTasks().firstOrNull()
                pendingTasks?.forEach { task ->
                    if (task.dueDate >= System.currentTimeMillis() - 86400000) {
                        scheduler.scheduleTaskAlarm(
                            taskId = task.id,
                            dateTimeMs = task.dueDate,
                            title = task.title,
                            category = task.category
                        )
                    }
                }
            }
        }
    }
}
