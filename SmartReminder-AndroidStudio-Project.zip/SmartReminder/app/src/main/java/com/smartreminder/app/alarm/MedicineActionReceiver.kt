package com.smartreminder.app.alarm

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.smartreminder.app.SmartReminderApp
import com.smartreminder.app.data.model.HistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MedicineActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TAKE_MEDICINE = "com.smartreminder.app.ACTION_TAKE_MEDICINE"
        const val ACTION_SNOOZE_MEDICINE = "com.smartreminder.app.ACTION_SNOOZE_MEDICINE"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val notificationId = intent.getIntExtra("EXTRA_NOTIF_ID", 0)
        val medicineId = intent.getLongExtra("EXTRA_MEDICINE_ID", -1L)
        val medicineName = intent.getStringExtra("EXTRA_MEDICINE_NAME") ?: "ওষুধ"
        val dose = intent.getStringExtra("EXTRA_DOSE") ?: ""
        val scheduledTime = intent.getStringExtra("EXTRA_SCHEDULED_TIME") ?: ""

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(notificationId)

        val app = context.applicationContext as SmartReminderApp
        val historyDao = app.database.historyDao()

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val now = Date()

        when (intent.action) {
            ACTION_TAKE_MEDICINE -> {
                Toast.makeText(context, "আলহামদুলিল্লাহ! ওষুধ গ্রহণ রেকর্ড করা হয়েছে।", Toast.LENGTH_SHORT).show()
                CoroutineScope(Dispatchers.IO).launch {
                    historyDao.insertHistory(
                        HistoryEntity(
                            medicineId = medicineId,
                            medicineName = medicineName,
                            dose = dose,
                            scheduledTime = scheduledTime,
                            actualTime = timeFormat.format(now),
                            status = "taken",
                            dateString = dateFormat.format(now)
                        )
                    )
                }
            }
            ACTION_SNOOZE_MEDICINE -> {
                Toast.makeText(context, "১০ মিনিট পর আবার মনে করিয়ে দেওয়া হবে।", Toast.LENGTH_SHORT).show()
                // Re-schedule alarm for 10 minutes later
                val scheduler = AndroidAlarmScheduler(context)
                val snoozeTimeMs = System.currentTimeMillis() + (10 * 60 * 1000)
                scheduler.scheduleTaskAlarm(
                    taskId = medicineId,
                    dateTimeMs = snoozeTimeMs,
                    title = "রিমাইন্ডার (Snooze): $medicineName",
                    category = "ওষুধ"
                )
            }
        }
    }
}
