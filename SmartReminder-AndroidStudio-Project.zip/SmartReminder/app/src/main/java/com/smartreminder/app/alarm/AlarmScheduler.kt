package com.smartreminder.app.alarm

interface AlarmScheduler {
    fun scheduleMedicineAlarm(medicineId: Long, timeString: String, label: String, medicineName: String, dose: String)
    fun scheduleTaskAlarm(taskId: Long, dateTimeMs: Long, title: String, category: String)
    fun cancelMedicineAlarm(requestCode: Int)
    fun cancelTaskAlarm(requestCode: Int)
}
