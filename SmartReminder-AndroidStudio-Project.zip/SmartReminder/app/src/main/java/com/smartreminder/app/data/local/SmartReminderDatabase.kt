package com.smartreminder.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.smartreminder.app.data.model.HistoryEntity
import com.smartreminder.app.data.model.MedicineEntity
import com.smartreminder.app.data.model.TaskEntity

@Database(
    entities = [MedicineEntity::class, TaskEntity::class, HistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SmartReminderDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun taskDao(): TaskDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: SmartReminderDatabase? = null

        fun getDatabase(context: Context): SmartReminderDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SmartReminderDatabase::class.java,
                    "smart_reminder_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
