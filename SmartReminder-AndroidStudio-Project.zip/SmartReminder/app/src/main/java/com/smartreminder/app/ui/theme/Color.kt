package com.smartreminder.app.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val EmeraldLight = Color(0xFFD1FAE5)
val EmeraldSurface = Color(0xFFF0FDF4)

val SlateDark = Color(0xFF0F172A)
val SlateMedium = Color(0xFF334155)
val SlateLight = Color(0xFFF8FAFC)
val CardBorder = Color(0xFFE2E8F0)

val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
