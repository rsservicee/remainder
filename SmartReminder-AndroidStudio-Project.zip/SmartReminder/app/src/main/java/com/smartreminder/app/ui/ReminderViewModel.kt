package com.smartreminder.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.smartreminder.app.alarm.AndroidAlarmScheduler
import com.smartreminder.app.data.local.HistoryDao
import com.smartreminder.app.data.local.MedicineDao
import com.smartreminder.app.data.local.TaskDao
import com.smartreminder.app.data.model.HistoryEntity
import com.smartreminder.app.data.model.MedicineEntity
import com.smartreminder.app.data.model.TaskEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(
    private val medicineDao: MedicineDao,
    private val taskDao: TaskDao,
    private val historyDao: HistoryDao,
    application: Application
) : AndroidViewModel(application) {

    private val alarmScheduler = AndroidAlarmScheduler(application)

    val medicines = medicineDao.getAllMedicines().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val tasks = taskDao.getAllTasks().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val history = historyDao.getAllHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addMedicine(medicine: MedicineEntity, timeList: List<String>) {
        viewModelScope.launch {
            val id = medicineDao.insertMedicine(medicine)
            timeList.forEach { time ->
                alarmScheduler.scheduleMedicineAlarm(
                    medicineId = id,
                    timeString = time,
                    label = "সময়সূচী",
                    medicineName = medicine.name,
                    dose = medicine.dose
                )
            }
        }
    }

    fun addTask(task: TaskEntity) {
        viewModelScope.launch {
            val id = taskDao.insertTask(task)
            alarmScheduler.scheduleTaskAlarm(
                taskId = id,
                dateTimeMs = task.dueDate,
                title = task.title,
                category = task.category
            )
        }
    }

    fun toggleTaskComplete(task: TaskEntity) {
        viewModelScope.launch {
            val nextState = !task.isCompleted
            val completedAt = if (nextState) System.currentTimeMillis() else null
            taskDao.setTaskCompleted(task.id, nextState, completedAt)
        }
    }

    fun deleteMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            medicineDao.deleteMedicine(medicine)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            taskDao.deleteTask(task)
        }
    }

    class Factory(
        private val medicineDao: MedicineDao,
        private val taskDao: TaskDao,
        private val historyDao: HistoryDao,
        private val application: Application
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReminderViewModel(medicineDao, taskDao, historyDao, application) as T
        }
    }
}
