package com.smartreminder.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "intake_history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val medicineId: Long,
    val medicineName: String,
    val dose: String,
    val scheduledTime: String,
    val actualTime: String,
    val status: String, // taken (গৃহীত), snoozed (বিলম্বিত), missed (অনুপস্থিত)
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String // "YYYY-MM-DD"
)
