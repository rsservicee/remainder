package com.smartreminder.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.smartreminder.app.MainActivity
import com.smartreminder.app.R
import com.smartreminder.app.alarm.MedicineActionReceiver

object NotificationHelper {

    const val CHANNEL_MEDICINE_ID = "channel_smart_reminder_medicine"
    const val CHANNEL_TASK_ID = "channel_smart_reminder_task"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .build()

            val medicineChannel = NotificationChannel(
                CHANNEL_MEDICINE_ID,
                "ওষুধের রিমাইন্ডার (Medicine)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ওষুধের গুরুত্বপূর্ণ সময়সূচী সংক্রান্ত নোটিফিকেশন"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
                setSound(alarmSound, audioAttributes)
            }

            val taskChannel = NotificationChannel(
                CHANNEL_TASK_ID,
                "কাজের রিমাইন্ডার (Tasks)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "প্রাত্যহিক কাজের অনুস্মারক নোটিফিকেশন"
                enableVibration(true)
                setSound(alarmSound, audioAttributes)
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(medicineChannel)
            manager.createNotificationChannel(taskChannel)
        }
    }

    fun showMedicineNotification(
        context: Context,
        notificationId: Int,
        medicineId: Long,
        title: String,
        message: String,
        scheduledTime: String
    ) {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action 1: "ওষুধ খেয়েছি" (Taken)
        val takeIntent = Intent(context, MedicineActionReceiver::class.java).apply {
            action = MedicineActionReceiver.ACTION_TAKE_MEDICINE
            putExtra("EXTRA_NOTIF_ID", notificationId)
            putExtra("EXTRA_MEDICINE_ID", medicineId)
            putExtra("EXTRA_MEDICINE_NAME", title)
            putExtra("EXTRA_SCHEDULED_TIME", scheduledTime)
        }
        val takePendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 1000,
            takeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action 2: "পরে মনে করিয়ে দাও" (Snooze 10 min)
        val snoozeIntent = Intent(context, MedicineActionReceiver::class.java).apply {
            action = MedicineActionReceiver.ACTION_SNOOZE_MEDICINE
            putExtra("EXTRA_NOTIF_ID", notificationId)
            putExtra("EXTRA_MEDICINE_ID", medicineId)
            putExtra("EXTRA_MEDICINE_NAME", title)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 2000,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MEDICINE_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$message\nওষুধ খাওয়া শেষে নিচে 'ওষুধ খেয়েছি' চাপুন।"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(0, "✅ ওষুধ খেয়েছি", takePendingIntent)
            .addAction(0, "⏰ পরে মনে করিয়ে দাও", snoozePendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, notification)
    }

    fun showTaskNotification(
        context: Context,
        notificationId: Int,
        taskId: Long,
        title: String,
        message: String
    ) {
        val openAppIntent = Intent(context, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_TASK_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, notification)
    }
}
