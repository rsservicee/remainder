package com.smartreminder.app

import android.app.Application
import com.smartreminder.app.data.local.SmartReminderDatabase
import com.smartreminder.app.notification.NotificationHelper

class SmartReminderApp : Application() {

    val database: SmartReminderDatabase by lazy {
        SmartReminderDatabase.getDatabase(this)
    }

    override fun onCreate() {
        super.onCreate()
        // Create high-importance notification channels for Medicine and Tasks
        NotificationHelper.createNotificationChannels(this)
    }
}
